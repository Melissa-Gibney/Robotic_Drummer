/*
  ==============================================================================

    This file contains the basic framework code for a JUCE plugin processor.

  ==============================================================================
*/

#include "PluginProcessor.h"
#include "PluginEditor.h"

//==============================================================================
Robotic_Drummer_Interface_MockupAudioProcessor::Robotic_Drummer_Interface_MockupAudioProcessor()
#ifndef JucePlugin_PreferredChannelConfigurations
     : AudioProcessor (BusesProperties()
                     #if ! JucePlugin_IsMidiEffect
                      #if ! JucePlugin_IsSynth
                       .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
                      #endif
                       .withOutput ("Output", juce::AudioChannelSet::stereo(), true)
                     #endif
                       )
#endif
{
    //Initialize Variables
    
    //Hi Hat Variables
    firstHiHatHit = false;
    secondHiHatHit = false;
    thirdHiHatHit = false;
    fourthHiHatHit = false;
    fifthHiHatHit = false;
    sixthHiHatHit = false;
    seventhHiHatHit = false;
    eighthHiHatHit = false;
    
    firstHiHatVelocity = 255;
    secondHiHatVelocity = 255;
    thirdHiHatVelocity = 255;
    fourthHiHatVelocity = 255;
    fifthHiHatVelocity = 255;
    sixthHiHatVelocity = 255;
    seventhHiHatVelocity = 255;
    eighthHiHatVelocity = 255;
    
    //Snare Variables
    firstSnareHit = false;
    secondSnareHit = false;
    thirdSnareHit = false;
    fourthSnareHit = false;
    fifthSnareHit = false;
    sixthSnareHit = false;
    seventhSnareHit = false;
    eighthSnareHit = false;
    
    firstSnareVelocity = 255;
    secondSnareVelocity = 255;
    thirdSnareVelocity = 255;
    fourthSnareVelocity = 255;
    fifthSnareVelocity = 255;
    sixthSnareVelocity = 255;
    seventhSnareVelocity = 255;
    eighthSnareVelocity = 255;
    
    //Tom Variables
    firstTomHit = false;
    secondTomHit = false;
    thirdTomHit = false;
    fourthTomHit = false;
    fifthTomHit = false;
    sixthTomHit = false;
    seventhTomHit = false;
    eighthTomHit = false;
    
    firstTomVelocity = 255;
    secondTomVelocity = 255;
    thirdTomVelocity = 255;
    fourthTomVelocity = 255;
    fifthTomVelocity = 255;
    sixthTomVelocity = 255;
    seventhTomVelocity = 255;
    eighthTomVelocity = 255;
    
    //Kick Variables
    firstKickHit = false;
    secondKickHit = false;
    thirdKickHit = false;
    fourthKickHit = false;
    fifthKickHit = false;
    sixthKickHit = false;
    seventhKickHit = false;
    eighthKickHit = false;
    
    firstKickVelocity = 255;
    secondKickVelocity = 255;
    thirdKickVelocity = 255;
    fourthKickVelocity = 255;
    fifthKickVelocity = 255;
    sixthKickVelocity = 255;
    seventhKickVelocity = 255;
    eighthKickVelocity = 255;
    
    //Initialize Tempo
    tempo = 120; //bpm
}

Robotic_Drummer_Interface_MockupAudioProcessor::~Robotic_Drummer_Interface_MockupAudioProcessor()
{
}

//==============================================================================
const juce::String Robotic_Drummer_Interface_MockupAudioProcessor::getName() const
{
    return JucePlugin_Name;
}

bool Robotic_Drummer_Interface_MockupAudioProcessor::acceptsMidi() const
{
   #if JucePlugin_WantsMidiInput
    return true;
   #else
    return false;
   #endif
}

bool Robotic_Drummer_Interface_MockupAudioProcessor::producesMidi() const
{
   #if JucePlugin_ProducesMidiOutput
    return true;
   #else
    return false;
   #endif
}

bool Robotic_Drummer_Interface_MockupAudioProcessor::isMidiEffect() const
{
   #if JucePlugin_IsMidiEffect
    return true;
   #else
    return false;
   #endif
}

double Robotic_Drummer_Interface_MockupAudioProcessor::getTailLengthSeconds() const
{
    return 0.0;
}

int Robotic_Drummer_Interface_MockupAudioProcessor::getNumPrograms()
{
    return 1;   // NB: some hosts don't cope very well if you tell them there are 0 programs,
                // so this should be at least 1, even if you're not really implementing programs.
}

int Robotic_Drummer_Interface_MockupAudioProcessor::getCurrentProgram()
{
    return 0;
}

void Robotic_Drummer_Interface_MockupAudioProcessor::setCurrentProgram (int index)
{
}

const juce::String Robotic_Drummer_Interface_MockupAudioProcessor::getProgramName (int index)
{
    return {};
}

void Robotic_Drummer_Interface_MockupAudioProcessor::changeProgramName (int index, const juce::String& newName)
{
}

//==============================================================================
void Robotic_Drummer_Interface_MockupAudioProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    // Use this method as the place to do any pre-playback
    // initialisation that you need..
}

void Robotic_Drummer_Interface_MockupAudioProcessor::releaseResources()
{
    // When playback stops, you can use this as an opportunity to free up any
    // spare memory, etc.
}

#ifndef JucePlugin_PreferredChannelConfigurations
bool Robotic_Drummer_Interface_MockupAudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
  #if JucePlugin_IsMidiEffect
    juce::ignoreUnused (layouts);
    return true;
  #else
    // This is the place where you check if the layout is supported.
    // In this template code we only support mono or stereo.
    // Some plugin hosts, such as certain GarageBand versions, will only
    // load plugins that support stereo bus layouts.
    if (layouts.getMainOutputChannelSet() != juce::AudioChannelSet::mono()
     && layouts.getMainOutputChannelSet() != juce::AudioChannelSet::stereo())
        return false;

    // This checks if the input layout matches the output layout
   #if ! JucePlugin_IsSynth
    if (layouts.getMainOutputChannelSet() != layouts.getMainInputChannelSet())
        return false;
   #endif

    return true;
  #endif
}
#endif

void Robotic_Drummer_Interface_MockupAudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midiMessages)
{
    
    
    juce::ScopedNoDenormals noDenormals;
    auto totalNumInputChannels  = getTotalNumInputChannels();
    auto totalNumOutputChannels = getTotalNumOutputChannels();

    // In case we have more outputs than inputs, this code clears any output
    // channels that didn't contain input data, (because these aren't
    // guaranteed to be empty - they may contain garbage).
    // This is here to avoid people getting screaming feedback
    // when they first compile a plugin, but obviously you don't need to keep
    // this code if your algorithm always overwrites all the output channels.
    for (auto i = totalNumInputChannels; i < totalNumOutputChannels; ++i)
        buffer.clear (i, 0, buffer.getNumSamples());

    // This is the place where you'd normally do the guts of your plugin's
    // audio processing...
    // Make sure to reset the state if your inner loop is processing
    // the samples and the outer loop is handling the channels.
    // Alternatively, you can process the samples with the channels
    // interleaved by keeping the same state.
    for (int channel = 0; channel < totalNumInputChannels; ++channel)
    {
        auto* channelData = buffer.getWritePointer (channel);

        // ..do something to the data...
    }
}

//==============================================================================
bool Robotic_Drummer_Interface_MockupAudioProcessor::hasEditor() const
{
    return true; // (change this to false if you choose to not supply an editor)
}

juce::AudioProcessorEditor* Robotic_Drummer_Interface_MockupAudioProcessor::createEditor()
{
    return new Robotic_Drummer_Interface_MockupAudioProcessorEditor (*this);
}

//==============================================================================
void Robotic_Drummer_Interface_MockupAudioProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    // You should use this method to store your parameters in the memory block.
    // You could do that either as raw data, or use the XML or ValueTree classes
    // as intermediaries to make it easy to save and load complex data.
}

void Robotic_Drummer_Interface_MockupAudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    // You should use this method to restore your parameters from this memory block,
    // whose contents will have been created by the getStateInformation() call.
}

//==============================================================================
// This creates new instances of the plugin..
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new Robotic_Drummer_Interface_MockupAudioProcessor();
}
